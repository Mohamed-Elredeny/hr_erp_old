<?php

return [

    'AboutUs' => 'Sobre Nosotros',
    'AboutText' => 'Free Building Trade International Co. (FBT) se estableció en 1996 y tiene sus oficinas principales en los Estados Unidos, Hong Kong, China, Jordania y también representantes en muchos países de todo el mundo. FBT cree en crear mercados que tengan la mayor posibilidad de alcanzarlos y brindar el conocimiento, el valor y los servicios que el cliente merece. FBT realiza negocios en todo el mundo basados en la calidad y los servicios de posventa que nos permiten construir relaciones sólidas basadas en la confianza con nuestros clientes.',    'ViewMore'=>'Ver más',
    'OurAdvantage'=>'Nuestra ventaja',
    'OurAdvantageText'=>'Todos nuestros sistemas de filtración de agua cumplen con los estándares internacionales de calidad y son muy apreciados en una variedad de mercados diferentes en todo el mundo',
    'Safer'=>'más seguro',
    'SaferText'=>'Descubrirá que el sistema de filtración de agua es una ruta simple hacia un agua más segura.',
    'BetterTasting'=>'Mejor sabor',
    'BetterTastingText'=>'¡Inspírate para mantenerte hidratado con un sabor más limpio y refrescante!',
    'Eco-Friendly'=>'amigo de la ecología',
    'Eco-FriendlyText'=>'Haga su parte por el medio ambiente y sea ecológico con un sistema de filtración de agua.',
    'OurProducts'=>'Nuestros productos',
    'ContactUsText'=>'Estamos aquí para ayudarle con sus preguntas sobre nuestros productos.',
    'ContactUs'=>'Contacto',
];
