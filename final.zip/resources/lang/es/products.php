<?php

return [

    'CATEGORIES' => 'CATEGORIAS',
    'MoreDetails' => 'Más detalles',
    'InquireNow'=>'Pregunte ahora',

];
