<?php

return [

    'QuickLinks' => 'Enlaces rápidos',
    'Home' => 'Inicio',
    'AboutUs'=>'Sobre',
    'Products'=>'Productos',
    'Videos'=>'Vídeos',
    'PrivacyPolicy'=>'Política de privacidad',
    'ContactUs'=>'Contacto',
    'copyright'=>'Copyright © Free Building Trade International Co. Todos los derechos reservados.',
    'Sitemap'=>'mapa del sitio',
    'PoweredBy'=>'Desarrollado por:',
    'Powered'=>'Palm Solutions',

    'Newsletter'=>'Boletin informativo',
    'Stay'=>'Manténgase actualizado con las últimas noticias y productos.',
    'email'=>'Introduce tu correo electrónico',
    'Subscribe'=>'Suscribir',
    'Youremail'=>'Su correo electrónico está seguro con nosotros, no hacemos spam.',
    'Keywords'=>'Palabras clave',

];
