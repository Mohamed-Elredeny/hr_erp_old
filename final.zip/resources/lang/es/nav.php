<?php

return [

    'HOME' => 'INICIO',
    'ABOUT-US' => 'SOBRE',
    'PRODUCTS'=>'PRODUCTOS',
    'VIDEOS'=>'VÍDEOS',
    'CONTACT-US'=>'CONTACTO',
    'Search'=>'Búsqueda',
];
