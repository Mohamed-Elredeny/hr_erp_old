<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Embassy extends Model
{
    protected $table ='embassyes';
    protected $fillable = [
        'name',
        'country'
    ];
}
