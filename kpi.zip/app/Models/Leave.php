<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Leave extends Model
{
    protected $table = 'leaves';
    protected $guarded = [];
    protected $states = [
        'handOver' => 'Hand Over Stag',
        'ManagerApproval1' => 'Department First Approval',
        'ManagerApproval2' => 'Department Second Approval',
        'ManagerApproval3' => 'Department Third Approval',
        'ManagerApproval4' => 'Department Fourth Approval',
        'ManagerApproval5' => 'Department Fifth Approval',
        'gmApproval' => 'GM Approval',
        'EmployeeRelation' => 'Employee Relation',
        'ClearanceAccommodation' => 'Accommodation Department',
        'ClearancePlant' => 'Plant Department',
        'ClearanceStores' => 'Stores Department',
        'ClearanceFinance' => 'Finance Department',
        'ClearanceIT' => 'IT Department',
        'HrApproval' => 'HR Approval',
        'GroupHRDirectorApproval' => 'Group HR Director Approval',
        'approved'=>'Approved'
    ];
    public function employee(){
        return $this->belongsTo(Employee::class, 'employee_id');
    }
    public function hasStages()
    {
        return $this->hasMany(LeaveStage::class, 'leave_id');
    }

    public function type()
    {
        return $this->belongsTo(LeaveType::class, 'leave_type_id');
    }

    public function responsible_employees($stage)
    {
        $res = [];
        $stages = LeaveStage::where('leave_id', $this->id)->where('stage_name', $stage)->pluck('responsible_employee')->toArray();
        foreach ($stages as $stage) {
            $emp = Employee::find($stage);
            if (isset($emp->empName)) {
                $res[] = $emp->empName . '-' . $emp->mobile;
            }
        }
        return $res;
    }

    public function my_role_in_leave($employee_id)
    {
        $res = [];
        $stages = LeaveStage::where('leave_id', $this->id)->where('responsible_employee', $employee_id)->pluck('stage_name')->toArray();
        foreach ($stages as $stage) {
            if (isset($this->states[$stage])) {
                $res[] = $this->states[$stage];
            }
        }
        return $res;
    }

    public function next_stage()
    {
        $res = [];
        $stages = LeaveStage::where('leave_id', $this->id)->pluck('stage_name')->toArray();
        $current_stages = array_values(array_unique($stages));
        $index = array_search($this->status, $current_stages);
        $count_stages = LeaveStage::where('leave_id', $this->id)->where('stage_name',$current_stages[$index] ?? $this->status)->where('status','!=','approved')->count();
        if (isset($current_stages[$index + 1]) && $count_stages <= 0 ) {
            return $current_stages[$index + 1];
        }
        return $current_stages[$index] ?? $this->status;
    }

    public function next_stage_pending_employees()
    {
        $stagex = $this->next_stage();
        $stages = LeaveStage::where('leave_id', $this->id)->where('stage_name', $stagex)->where('status','!=','approved')->pluck('responsible_employee')->toArray();
        foreach ($stages as $stage) {
            $emp = Employee::find($stage);
            if (isset($emp->empName)) {
                $res[] = $emp->empName . '-' . $emp->mobile;
            }
        }
        return $res ?? [$this->states[$stagex] . " team"];
    }
}
