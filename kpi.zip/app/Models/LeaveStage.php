<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LeaveStage extends Model
{
    protected $table = 'user_leaves_stages';
    protected $guarded = [];

    protected $states = [
        'handOver' => 'Hand Over Stag',
        'ManagerApproval1' => 'Department First Approval',
        'ManagerApproval2' => 'Department Second Approval',
        'ManagerApproval3' => 'Department Third Approval',
        'ManagerApproval4' => 'Department Fourth Approval',
        'ManagerApproval5' => 'Department Fifth Approval',
        'gmApproval' => 'Gm Approval',
        'EmployeeRelation' => 'Employee Relation',
        'ClearanceAccommodation' => 'Accommodation Department',
        'ClearancePlant' => 'Plant Department',
        'ClearanceStores' => 'Stores Department',
        'ClearanceFinance' => 'Finance Department',
        'ClearanceIT' => 'IT Department',
        'HrApproval' => 'Hr Approval',
        'GroupHRDirectorApproval' => 'Group HR Director Approval',
        'approved' => 'Approved'
    ];

    public function empLeaves($employee_id, $status)
    {
        return Leave::where('leave_type_id', $this->id)->where('status', $status)->where('employee_id', $employee_id)->get();
    }

    public function employee()
    {
        return $this->belongsTo(Employee::class, 'responsible_employee');
    }

    public function leave()
    {
        return $this->belongsTo(Leave::class, 'leave_id');
    }

    public function avilableStage($stageName)
    {
        //List of states
        $flag = 1;
        foreach ($this->states as $state => $value) {
            if ($stageName != $state) {
                $original_leave_stages = LeaveStage::where('leave_id', $this->leave_id)->where('stage_name', $state)->count();
                $approved_leave_stages = LeaveStage::where('leave_id', $this->leave_id)->where('stage_name', $state)->where('status', 'approved')->count();
                if ($original_leave_stages > $approved_leave_stages && $original_leave_stages >= 0) {
                    $flag = 0;
                }
            } else {
                break;
            }
        }
        return $flag;

    }

}
