@extends('layouts.site')
@section('content')
    <div class="container  p-5 text-left" style="font-weight: bolder">
        <div class="row">
            <div class="col-sm-12 text-center h5">
                Policy and Procedure
                Travel and Leave
            </div>
        </div>
        <div>
            <br>

            <u><b>Eligibility of Ticket</b></u><br>

            Employees under staff category are entitled for a return Air ticket on completion of 365 working days
            which includes 30 calendar days’ leave.
            <br><br>
            <u><b>Fixing of Permanent Destination</b></u><br>

            The place of destination will be determined by HR department based on passport address and joining form
            filled by employee and can only be changed upon form submission to HR advising a valid reason for the
            change.
            <br><br>
            <u><b>Temporary change of Destination</b></u><br>
            If the ticket is arranged by the company and the employee want to change the timing or reroute for
            personal reasons, this should be done through HR department and the difference in cost will be borne by
            the employee.
            <br><br>
            If the ticket is changed while employee on leave as per his/her request, the incurred difference will be
            charged to his/her personal once he rejoin from leave
            <br><br>

            <u><b> Ticket issuing Procedure.</b></u><br>

            Upon receipt of the approved leave application in compliance to the company policy, the Employee
            relation staff should book the ticket thru Amadeus to purchase thru company approved.
            <br><br>

            <u><b> Business Travel.</b></u><br>
            For business travel, prior approval from GM on leave request is required prior to proceeding with
            issuing any ticket.
            <br><br>
            <u><b> Business Leave</b></u><br>
            Granted for employees to go for meetings / visits which is related to work.
            <br><br>

            <u><b> Annual Leave</b></u><br>

            1. Staff who have completed 12 months of continuous service are entitled for paid annual leave on
            completion of their first year of service. Thereafter employees who have returned from leave and
            completed 11 months (335/336 days) of subsequent continuous service will be entitled to 30 days leave
            for subsequent periods of service.
            <br>
            2. Employees should require to attend the work on the day of leave departure and leave resumption.
            <br><br>
            <u><b> Unpaid Leave</b></u><br>
            <ul>
                <li>
                    1. Leave requested by employee in time of non — entitlement of annual leave and granted only subject to
                    his
                    manager’s approval
                </li>
                <li>
                    2. Need to submit relevant/supporting documents for availing unpaid leave during 1st year with company.
                </li>
                <li>
                    3. Employees should require to attend the work on the day of leave departure and leave resumption.
                </li>
            </ul>

            <br><br>
            <u><b> Casual leave</b></u><br>

            1. Granted for employees upon request and is limited to maximum 3 days per working year subject that the
            leave if to be used while in Qatar.
            <br><br>
            2. 3 days’ casual leave granted in a year should not be availed continuously for 3 days.
            Casual leave will be eligible only upon completion of their first year of service.
            <br><br>
            <u><b> Sick leave</b></u><br>

            1. It’s leave granted from selected hospital that grant employee leave while sick and this is reimbursed on
            the basis of 14 days’ full salary and 28 days half salary and afterward its considered as unpaid unless
            its work related injury.
            <br>
            2. No Sick leave during probation period and any sick leave needs to be validated with a medical
            certificate from a local doctor certified in Qatar.
            <br>
            3. The approved sick leave days issued from Qatar certified doctors or hospital as per above can spend in
            home country if the leave is above 7 days and also subject to duly filled Leave request form with
            relevant approvals.
            <br><br>

            <u><b> Maternity leave</b></u><br>

            Granted upon delivery and for employees who completed more than a year with the company and is limited
            to 50 days.
            <br><br>
            <u><b> Compassionate leave</b></u><br>

            1. The purpose of this policy is to clarify the extent of support ENSRV Group provide to staff in case of
            sudden demise of one of their immediate relatives.
            <br>
            2. Immediate Relatives: includes Father, Mother, Spouse, Son or Daughter.
            This policy applies only to all employees under staff payroll who completed one year of service with the
            company.
            <br>
            3. 5 days paid leave and a round trip ticket shall be provided to staff travelling due to the demise of an
            immediate relative (a leave request should be submitted for that reason and leave type shall be
            compassionate leave).
            <br>
            4. If compassionate leave exceeds 10 days, employee will not be eligible for 5 days paid leave and
            compassionate Ticket.
            <br>
            5. This policy will not be applicable in case of any staff has resigned or while serving a notice period.
            <br>
            6. If an employee went on unpaid leave due to known reason of disease of his immediate relatives and the
            death happened within a period of 10 days of his travel from Doha, the ticket he purchased can be
            reimbursed. This ticket will set off against the forthcoming ticket due date.
            <br>
            7. If the death happens during leave, no days’ reimbursement can be claimed by employee in such case.
            <br>
            8. Upon rejoining from compassionate leave, a death certificate issued from the relevant authorized
            department in home country shall be submitted for HR records within a period of one month.
            <br><br>
            <u><b> Deviation from the leave</b></u><br>

            Any deviation from the above policy will be subject to approval by Group HR Director
            <br>
            The policy can be updated or modified as per HR policy requirements.
        </div>
    </div>
@endsection
