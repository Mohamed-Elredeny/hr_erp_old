<?php

return [

    'ContactUs' => 'Contacto',
    'ContactUsText' => '
Ya sea que desee obtener más información sobre qué, por qué y cómo hacemos lo que hacemos, si necesita ayuda con lo que está creando, si desea asociarse o simplemente saludar, nos encantaría saber de usted',    'GetTouch'=>'Ponte en contacto con nosotros',
    'Name'=>'Nombre',
    'Email'=>'Email',
    'Tel'=>'Teléfono',
    'Country'=>'País',
    'Company'=>'Empresa',
    'Message'=>'Mensaje',
    'SEND'=>'ENVIAR',
    'ProductName'=>'nombre del producto',
    'ProductImage'=>'Product Image',
    'Show'=>'Show',
];
