<?php

return [

    'PRODUCTS' => 'PRODUCTOS',
    'share' => 'Cuota',
    'InquireNow'=>'Pregunte ahora',
    'ProductDescription'=>'Descripción del producto',
    'Overview'=>'Visión de conjunto',
    'Downloads'=>'Descargas',
    'RelatedProducts'=>'Productos relacionados',
];
